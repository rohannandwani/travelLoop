export type Visibility = "private" | "friends" | "public";

export type Category =
  | "Food"
  | "Culture"
  | "Nature"
  | "Transit"
  | "Stay"
  | "Shopping"
  | "Nightlife"
  | "Wellness";

export type CityStop = {
  id: string;
  city: string;
  country: string;
  startDate: string;
  endDate: string;
  vibe: string;
};

export type Activity = {
  id: string;
  title: string;
  city: string;
  date: string;
  time: string;
  category: Category;
  cost: number;
  durationHours: number;
  notes: string;
  votes: number;
  isLocked?: boolean;
};

export type Collaborator = {
  id: string;
  email: string;
  role: "viewer" | "editor";
};

export type Trip = {
  id: string;
  title: string;
  prompt: string;
  visibility: Visibility;
  budgetLimit: number;
  currency: "USD" | "INR" | "EUR" | "JPY";
  cityStops: CityStop[];
  activities: Activity[];
  collaborators: Collaborator[];
};

export type DiscoveryItem = {
  id: string;
  title: string;
  city: string;
  category: Category;
  cost: number;
  durationHours: number;
  time: string;
  notes: string;
  tags: string[];
};
