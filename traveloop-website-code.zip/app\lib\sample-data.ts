import type { Activity, CityStop, DiscoveryItem, Trip } from "./types";

export const cityStops: CityStop[] = [
  {
    id: "city-tokyo",
    city: "Tokyo",
    country: "Japan",
    startDate: "2026-06-12",
    endDate: "2026-06-14",
    vibe: "Food, neon districts, quiet gardens"
  },
  {
    id: "city-kyoto",
    city: "Kyoto",
    country: "Japan",
    startDate: "2026-06-15",
    endDate: "2026-06-17",
    vibe: "Temples, tea houses, slow mornings"
  },
  {
    id: "city-osaka",
    city: "Osaka",
    country: "Japan",
    startDate: "2026-06-18",
    endDate: "2026-06-19",
    vibe: "Street food, markets, nightlife"
  }
];

export const activities: Activity[] = [
  {
    id: "act-tsukiji",
    title: "Tsukiji breakfast crawl",
    city: "Tokyo",
    date: "2026-06-12",
    time: "08:30",
    category: "Food",
    cost: 42,
    durationHours: 2,
    notes: "Sushi, tamagoyaki, coffee, and a quick market walk.",
    votes: 4,
    isLocked: true
  },
  {
    id: "act-shibuya",
    title: "Shibuya and Harajuku loop",
    city: "Tokyo",
    date: "2026-06-12",
    time: "15:00",
    category: "Culture",
    cost: 24,
    durationHours: 3,
    notes: "Crossing, Cat Street, and small design stores.",
    votes: 3
  },
  {
    id: "act-ghibli",
    title: "Kichijoji hidden cafes",
    city: "Tokyo",
    date: "2026-06-13",
    time: "11:00",
    category: "Food",
    cost: 36,
    durationHours: 3,
    notes: "Local cafes near Inokashira Park.",
    votes: 5
  },
  {
    id: "act-fushimi",
    title: "Fushimi Inari sunrise walk",
    city: "Kyoto",
    date: "2026-06-15",
    time: "06:30",
    category: "Nature",
    cost: 0,
    durationHours: 2.5,
    notes: "Early climb before crowds, then breakfast nearby.",
    votes: 6,
    isLocked: true
  },
  {
    id: "act-tea",
    title: "Gion tea tasting",
    city: "Kyoto",
    date: "2026-06-16",
    time: "14:00",
    category: "Culture",
    cost: 58,
    durationHours: 1.5,
    notes: "Book a small group session near Hanamikoji.",
    votes: 2
  },
  {
    id: "act-dotonbori",
    title: "Dotonbori dinner map",
    city: "Osaka",
    date: "2026-06-18",
    time: "19:00",
    category: "Food",
    cost: 54,
    durationHours: 3,
    notes: "Takoyaki, okonomiyaki, and dessert stops.",
    votes: 7,
    isLocked: true
  }
];

export const initialTrip: Trip = {
  id: "traveloop-demo",
  title: "Japan Food & Culture Loop",
  prompt:
    "Plan an 8-day budget-friendly Japan trip for friends who love food, quiet neighborhoods, and local culture.",
  visibility: "friends",
  budgetLimit: 1800,
  currency: "USD",
  cityStops,
  activities,
  collaborators: [
    { id: "collab-1", email: "maya@example.com", role: "editor" },
    { id: "collab-2", email: "arjun@example.com", role: "viewer" }
  ]
};

export const discoveryItems: DiscoveryItem[] = [
  {
    id: "disc-yanaka",
    title: "Yanaka backstreet photo walk",
    city: "Tokyo",
    category: "Culture",
    cost: 18,
    durationHours: 2,
    time: "10:00",
    notes: "Old Tokyo lanes, small galleries, and local snacks.",
    tags: ["hidden gem", "walking", "local"]
  },
  {
    id: "disc-sento",
    title: "Neighborhood sento reset",
    city: "Tokyo",
    category: "Wellness",
    cost: 8,
    durationHours: 1.5,
    time: "20:30",
    notes: "A calm bathhouse stop after a heavy walking day.",
    tags: ["offline-friendly", "low cost", "evening"]
  },
  {
    id: "disc-arashiyama",
    title: "Arashiyama river picnic",
    city: "Kyoto",
    category: "Nature",
    cost: 16,
    durationHours: 3,
    time: "11:30",
    notes: "Bamboo grove, river walk, and snacks from a nearby market.",
    tags: ["scenic", "slow travel", "friends"]
  },
  {
    id: "disc-nishiki",
    title: "Nishiki Market tasting route",
    city: "Kyoto",
    category: "Food",
    cost: 34,
    durationHours: 2,
    time: "12:00",
    notes: "Pick five stalls and cap spending before the walk begins.",
    tags: ["food", "budget", "market"]
  },
  {
    id: "disc-kuromon",
    title: "Kuromon Ichiba chef picks",
    city: "Osaka",
    category: "Food",
    cost: 40,
    durationHours: 2,
    time: "11:00",
    notes: "Seafood bites, fruit, and a quick knife shop detour.",
    tags: ["food", "market", "group favorite"]
  },
  {
    id: "disc-teamlab",
    title: "teamLab evening slot",
    city: "Tokyo",
    category: "Culture",
    cost: 32,
    durationHours: 2,
    time: "18:00",
    notes: "Book the late slot to avoid losing a full daytime block.",
    tags: ["booking", "indoor", "visual"]
  },
  {
    id: "disc-namba",
    title: "Namba tiny bar crawl",
    city: "Osaka",
    category: "Nightlife",
    cost: 48,
    durationHours: 3,
    time: "21:00",
    notes: "Three small bars with a hard budget cap for the group.",
    tags: ["night", "group", "local"]
  },
  {
    id: "disc-train",
    title: "Kyoto to Osaka rail transfer",
    city: "Kyoto",
    category: "Transit",
    cost: 9,
    durationHours: 1,
    time: "09:30",
    notes: "A quick transfer block so the calendar stays realistic.",
    tags: ["transit", "planning", "low friction"]
  }
];
