import { NextRequest, NextResponse } from "next/server";
import { discoveryItems } from "../../lib/sample-data";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get("query")?.toLowerCase().trim() ?? "";
  const city = searchParams.get("city")?.toLowerCase().trim() ?? "";
  const type = searchParams.get("type")?.toLowerCase().trim() ?? "";

  const results = discoveryItems.filter((item) => {
    const matchesQuery =
      !query ||
      item.title.toLowerCase().includes(query) ||
      item.notes.toLowerCase().includes(query) ||
      item.tags.some((tag) => tag.toLowerCase().includes(query));
    const matchesCity = !city || item.city.toLowerCase() === city;
    const matchesType = !type || item.category.toLowerCase() === type;

    return matchesQuery && matchesCity && matchesType;
  });

  return NextResponse.json({
    results,
    total: results.length
  });
}
