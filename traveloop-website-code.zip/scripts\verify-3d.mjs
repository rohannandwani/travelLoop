import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const chromePath = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const debugPort = 9337;
const url = "http://127.0.0.1:3000";

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchJson(endpoint) {
  const response = await fetch(endpoint);

  if (!response.ok) {
    throw new Error(`${endpoint} returned ${response.status}`);
  }

  return response.json();
}

async function connectToPage() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const pages = await fetchJson(`http://127.0.0.1:${debugPort}/json`);
      const page = pages.find((item) => item.type === "page") ?? pages[0];

      if (page?.webSocketDebuggerUrl) {
        return new WebSocket(page.webSocketDebuggerUrl);
      }
    } catch {
      await wait(250);
    }
  }

  throw new Error("Chrome debugging endpoint did not become ready.");
}

function createCdpClient(socket) {
  let nextId = 1;
  const pending = new Map();

  socket.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);

    if (message.id && pending.has(message.id)) {
      const { resolve, reject } = pending.get(message.id);
      pending.delete(message.id);

      if (message.error) {
        reject(new Error(message.error.message));
      } else {
        resolve(message.result);
      }
    }
  });

  return {
    send(method, params = {}) {
      const id = nextId;
      nextId += 1;
      socket.send(JSON.stringify({ id, method, params }));

      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
      });
    }
  };
}

async function runViewport(client, name, width, height, isMobile) {
  await client.send("Emulation.setDeviceMetricsOverride", {
    width,
    height,
    deviceScaleFactor: isMobile ? 2 : 1,
    mobile: isMobile
  });
  await client.send("Page.navigate", { url });
  await wait(2400);

  const screenshot = await client.send("Page.captureScreenshot", {
    format: "png",
    captureBeyondViewport: false
  });
  await fs.writeFile(path.join(root, `verification-${name}.png`), Buffer.from(screenshot.data, "base64"));

  const evaluation = await client.send("Runtime.evaluate", {
    returnByValue: true,
    expression: `(() => {
      const canvas = document.querySelector(".orbit-canvas canvas");
      if (!canvas) return { ok: false, reason: "missing canvas" };
      const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
      if (!gl) return { ok: false, reason: "missing webgl context" };
      const width = canvas.width;
      const height = canvas.height;
      const pixels = new Uint8Array(width * height * 4);
      gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
      let visiblePixels = 0;
      let brightPixels = 0;
      for (let index = 0; index < pixels.length; index += 4) {
        const alpha = pixels[index + 3];
        const brightness = pixels[index] + pixels[index + 1] + pixels[index + 2];
        if (alpha > 0) visiblePixels += 1;
        if (alpha > 0 && brightness > 120) brightPixels += 1;
      }
      return {
        ok: visiblePixels > 800 && brightPixels > 80,
        width,
        height,
        visiblePixels,
        brightPixels,
        ratio: Number((visiblePixels / (width * height)).toFixed(4))
      };
    })()`
  });

  return {
    name,
    width,
    height,
    ...evaluation.result.value
  };
}

await fs.rm(path.join(root, ".chrome-verify"), { recursive: true, force: true });
const chrome = spawn(chromePath, [
  "--headless=new",
  "--disable-gpu",
  "--no-first-run",
  "--no-default-browser-check",
  `--remote-debugging-port=${debugPort}`,
  `--user-data-dir=${path.join(root, ".chrome-verify")}`,
  "--window-size=1440,920",
  url
]);

try {
  const socket = await connectToPage();
  await new Promise((resolve) => socket.addEventListener("open", resolve, { once: true }));
  const client = createCdpClient(socket);
  await client.send("Page.enable");
  await client.send("Runtime.enable");

  const desktop = await runViewport(client, "desktop", 1440, 920, false);
  const mobile = await runViewport(client, "mobile", 390, 844, true);

  await client.send("Emulation.clearDeviceMetricsOverride");
  socket.close();

  const result = { desktop, mobile };
  await fs.writeFile(path.join(root, "verification-3d.json"), `${JSON.stringify(result, null, 2)}\n`);

  if (!desktop.ok || !mobile.ok) {
    throw new Error(`3D verification failed: ${JSON.stringify(result)}`);
  }

  console.log(JSON.stringify(result, null, 2));
} finally {
  chrome.kill();
}
