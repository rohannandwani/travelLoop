"use client";

import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { CityStop } from "../lib/types";

type TravelOrbitSceneProps = {
  stops: CityStop[];
  totalCost: number;
  dayCount: number;
  activityCount: number;
};

const knownCoordinates: Record<string, { lat: number; lon: number }> = {
  tokyo: { lat: 35.6762, lon: 139.6503 },
  kyoto: { lat: 35.0116, lon: 135.7681 },
  osaka: { lat: 34.6937, lon: 135.5023 },
  paris: { lat: 48.8566, lon: 2.3522 },
  london: { lat: 51.5072, lon: -0.1276 },
  "new york": { lat: 40.7128, lon: -74.006 },
  bali: { lat: -8.3405, lon: 115.092 },
  singapore: { lat: 1.3521, lon: 103.8198 },
  dubai: { lat: 25.2048, lon: 55.2708 },
  delhi: { lat: 28.6139, lon: 77.209 },
  mumbai: { lat: 19.076, lon: 72.8777 },
  bangkok: { lat: 13.7563, lon: 100.5018 },
  seoul: { lat: 37.5665, lon: 126.978 },
  sydney: { lat: -33.8688, lon: 151.2093 }
};

function cityCoordinates(city: string, index: number) {
  const known = knownCoordinates[city.toLowerCase()];

  if (known) {
    return known;
  }

  const seed = city.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0) + index * 47;

  return {
    lat: ((seed % 120) - 60) * 0.85,
    lon: ((seed * 7) % 300) - 150
  };
}

function latLonToVector(lat: number, lon: number, radius: number) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);

  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

function makeRouteCurve(start: THREE.Vector3, end: THREE.Vector3) {
  const midpoint = start.clone().add(end).normalize().multiplyScalar(2.05);

  return new THREE.QuadraticBezierCurve3(start, midpoint, end);
}

function makeAircraft() {
  const aircraft = new THREE.Group();
  const bodyMaterial = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    metalness: 0.48,
    roughness: 0.26
  });
  const accentMaterial = new THREE.MeshStandardMaterial({
    color: 0xf76f53,
    emissive: 0x441004,
    emissiveIntensity: 0.4
  });

  const body = new THREE.Mesh(new THREE.ConeGeometry(0.075, 0.38, 24), bodyMaterial);
  body.rotation.x = Math.PI / 2;
  aircraft.add(body);

  const wing = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.018, 0.12), accentMaterial);
  wing.position.z = -0.02;
  aircraft.add(wing);

  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.018, 0.16), bodyMaterial);
  tail.position.z = -0.15;
  tail.rotation.z = Math.PI / 2;
  aircraft.add(tail);

  return aircraft;
}

export default function TravelOrbitScene({ stops, totalCost, dayCount, activityCount }: TravelOrbitSceneProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const cityPoints = useMemo(
    () =>
      stops.map((stop, index) => {
        const coordinates = cityCoordinates(stop.city, index);

        return {
          ...stop,
          position: latLonToVector(coordinates.lat, coordinates.lon, 1.28)
        };
      }),
    [stops]
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = canvas?.parentElement;

    if (!canvas || !container) {
      return;
    }

    const host = container;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
    camera.position.set(0, 0.45, 4.8);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const ambient = new THREE.AmbientLight(0xffffff, 1.2);
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
    keyLight.position.set(3, 4, 5);
    const rimLight = new THREE.DirectionalLight(0x43aa8b, 1.5);
    rimLight.position.set(-4, -1, 2);
    scene.add(ambient, keyLight, rimLight);

    const globe = new THREE.Group();
    scene.add(globe);

    const ocean = new THREE.Mesh(
      new THREE.SphereGeometry(1.22, 64, 64),
      new THREE.MeshStandardMaterial({
        color: 0x277da1,
        metalness: 0.14,
        roughness: 0.38,
        transparent: true,
        opacity: 0.9
      })
    );
    globe.add(ocean);

    const wire = new THREE.Mesh(
      new THREE.IcosahedronGeometry(1.235, 4),
      new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.13,
        wireframe: true
      })
    );
    globe.add(wire);

    const latitudeGroup = new THREE.Group();
    for (let index = -3; index <= 3; index += 1) {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(Math.cos(index * 0.25) * 1.24, 0.003, 8, 120),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.12 })
      );
      ring.position.y = Math.sin(index * 0.25) * 1.24;
      ring.rotation.x = Math.PI / 2;
      latitudeGroup.add(ring);
    }
    globe.add(latitudeGroup);

    const routeGroup = new THREE.Group();
    scene.add(routeGroup);

    const nodeMaterial = new THREE.MeshStandardMaterial({
      color: 0xf9c74f,
      emissive: 0xf76f53,
      emissiveIntensity: 0.75,
      metalness: 0.2,
      roughness: 0.2
    });
    const routeMaterial = new THREE.LineBasicMaterial({ color: 0xf76f53, transparent: true, opacity: 0.92 });
    const pulseMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.48 });

    cityPoints.forEach((point) => {
      const node = new THREE.Mesh(new THREE.SphereGeometry(0.045, 24, 24), nodeMaterial);
      node.position.copy(point.position);
      routeGroup.add(node);

      const pulse = new THREE.Mesh(new THREE.SphereGeometry(0.078, 24, 24), pulseMaterial);
      pulse.position.copy(point.position);
      routeGroup.add(pulse);
    });

    const routeCurves: THREE.QuadraticBezierCurve3[] = [];
    for (let index = 0; index < cityPoints.length - 1; index += 1) {
      const curve = makeRouteCurve(cityPoints[index].position, cityPoints[index + 1].position);
      routeCurves.push(curve);

      const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(curve.getPoints(96)), routeMaterial);
      routeGroup.add(line);
    }

    if (cityPoints.length > 2) {
      const curve = makeRouteCurve(cityPoints[cityPoints.length - 1].position, cityPoints[0].position);
      routeCurves.push(curve);
      routeGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(curve.getPoints(96)), routeMaterial));
    }

    const aircraft = makeAircraft();
    scene.add(aircraft);

    const stars = new THREE.Group();
    const starMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.42 });
    const starGeometry = new THREE.SphereGeometry(0.006, 8, 8);
    for (let index = 0; index < 110; index += 1) {
      const star = new THREE.Mesh(starGeometry, starMaterial);
      const angle = index * 2.399;
      const radius = 2.1 + (index % 9) * 0.045;
      star.position.set(Math.cos(angle) * radius, Math.sin(index * 1.71) * 1.2, Math.sin(angle) * radius);
      stars.add(star);
    }
    scene.add(stars);

    function resize() {
      const { width, height } = host.getBoundingClientRect();
      renderer.setSize(width, height, false);
      camera.aspect = width / Math.max(height, 1);
      camera.updateProjectionMatrix();
    }

    let frame = 0;
    let animationId = 0;

    function animate() {
      frame += 0.008;
      globe.rotation.y += 0.0028;
      routeGroup.rotation.y = globe.rotation.y;
      stars.rotation.y -= 0.0009;

      routeGroup.children.forEach((child, index) => {
        if (child instanceof THREE.Mesh && index % 2 === 1) {
          const scale = 1 + Math.sin(frame * 5 + index) * 0.16;
          child.scale.setScalar(scale);
        }
      });

      const activeCurve = routeCurves.length > 0 ? routeCurves[Math.floor(frame * 0.55) % routeCurves.length] : null;
      if (activeCurve) {
        const t = (frame * 0.55) % 1;
        const current = activeCurve.getPoint(t).applyAxisAngle(new THREE.Vector3(0, 1, 0), globe.rotation.y);
        const next = activeCurve.getPoint(Math.min(1, t + 0.01)).applyAxisAngle(new THREE.Vector3(0, 1, 0), globe.rotation.y);
        aircraft.position.copy(current);
        aircraft.lookAt(next);
        aircraft.scale.setScalar(1.05);
      } else {
        aircraft.position.set(0, 0.2, 1.7);
      }

      renderer.render(scene, camera);
      animationId = window.requestAnimationFrame(animate);
    }

    resize();
    window.addEventListener("resize", resize);
    animate();

    return () => {
      window.cancelAnimationFrame(animationId);
      window.removeEventListener("resize", resize);
      renderer.dispose();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          const material = object.material;
          if (Array.isArray(material)) {
            material.forEach((item) => item.dispose());
          } else {
            material.dispose();
          }
        }
      });
    };
  }, [cityPoints]);

  return (
    <section className="orbit-stage" aria-label="Traveloop route atlas">
      <div className="orbit-copy">
        <p className="eyebrow">Route Atlas</p>
        <h2>Multi-city trips, visualized in motion.</h2>
        <div className="orbit-metrics" aria-label="Trip summary">
          <span>{stops.length} stops</span>
          <span>{dayCount} days</span>
          <span>{activityCount} activities</span>
          <span>${totalCost.toLocaleString("en-US")} planned</span>
        </div>
      </div>
      <div className="orbit-canvas">
        <canvas ref={canvasRef} />
      </div>
    </section>
  );
}
