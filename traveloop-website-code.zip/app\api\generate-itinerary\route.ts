import { NextRequest, NextResponse } from "next/server";
import type { Activity, Category, CityStop } from "../../lib/types";

type GenerateRequest = {
  prompt?: string;
  cityStops?: CityStop[];
  budgetLimit?: number;
};

const categoryMap: Record<string, Category> = {
  food: "Food",
  cafe: "Food",
  market: "Food",
  museum: "Culture",
  culture: "Culture",
  temple: "Culture",
  hike: "Nature",
  nature: "Nature",
  train: "Transit",
  shopping: "Shopping",
  night: "Nightlife",
  spa: "Wellness"
};

function daysBetween(start: string, end: string) {
  const days: string[] = [];
  const [startYear, startMonth, startDay] = start.split("-").map(Number);
  const [endYear, endMonth, endDay] = end.split("-").map(Number);
  const cursor = new Date(Date.UTC(startYear, startMonth - 1, startDay));
  const endDate = new Date(Date.UTC(endYear, endMonth - 1, endDay));

  while (cursor <= endDate) {
    days.push(cursor.toISOString().slice(0, 10));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }

  return days;
}

function inferCategory(prompt: string, index: number): Category {
  const lower = prompt.toLowerCase();
  const found = Object.entries(categoryMap).find(([token]) => lower.includes(token));

  if (found) {
    return found[1];
  }

  const rotation: Category[] = [
    "Food",
    "Culture",
    "Nature",
    "Transit",
    "Shopping",
    "Nightlife"
  ];

  return rotation[index % rotation.length];
}

function makeActivity(stop: CityStop, date: string, index: number, prompt: string, dailyBudget: number): Activity {
  const category = inferCategory(prompt, index);
  const theme =
    category === "Food"
      ? "local tasting route"
      : category === "Culture"
        ? "heritage and neighborhood walk"
        : category === "Nature"
          ? "green escape block"
          : category === "Transit"
            ? "transfer and reset window"
            : category === "Nightlife"
              ? "evening social loop"
              : "curated discovery stop";
  const time = ["09:00", "11:30", "15:00", "18:30"][index % 4];
  const cost =
    category === "Transit"
      ? Math.max(8, Math.round(dailyBudget * 0.1))
      : category === "Nature"
        ? Math.max(0, Math.round(dailyBudget * 0.16))
        : Math.max(18, Math.round(dailyBudget * (0.18 + (index % 3) * 0.05)));

  return {
    id: `ai-${stop.city.toLowerCase()}-${date}-${index}`.replace(/\s+/g, "-"),
    title: `${stop.city} ${theme}`,
    city: stop.city,
    date,
    time,
    category,
    cost,
    durationHours: category === "Transit" ? 1 : 2 + (index % 2),
    notes: `Generated from: "${prompt.slice(0, 88)}${prompt.length > 88 ? "..." : ""}"`,
    votes: 0
  };
}

export async function POST(request: NextRequest) {
  const body = (await request.json()) as GenerateRequest;
  const prompt = body.prompt?.trim() || "Build a balanced multi-city itinerary.";
  const cityStops = body.cityStops?.length ? body.cityStops : [];
  const totalDays = cityStops.reduce(
    (count, stop) => count + daysBetween(stop.startDate, stop.endDate).length,
    0
  );
  const dailyBudget = Math.max(35, Math.round((body.budgetLimit ?? 1200) / Math.max(totalDays, 1)));

  const activities = cityStops.flatMap((stop, stopIndex) =>
    daysBetween(stop.startDate, stop.endDate).flatMap((date, dayIndex) => {
      const seed = stopIndex + dayIndex;
      const base = makeActivity(stop, date, seed, prompt, dailyBudget);
      const second =
        dayIndex % 2 === 0
          ? makeActivity(stop, date, seed + 7, `${prompt} hidden gem`, Math.round(dailyBudget * 0.7))
          : null;

      return second ? [base, { ...second, time: "16:30" }] : [base];
    })
  );

  return NextResponse.json({
    summary: `Generated ${activities.length} plan blocks across ${cityStops.length} cities.`,
    activities
  });
}
