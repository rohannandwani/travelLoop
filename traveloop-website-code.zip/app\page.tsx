"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import TravelOrbitScene from "./components/TravelOrbitScene";
import { initialTrip } from "./lib/sample-data";
import type { Activity, Category, CityStop, Collaborator, DiscoveryItem, Trip, Visibility } from "./lib/types";

const categories: Category[] = [
  "Food",
  "Culture",
  "Nature",
  "Transit",
  "Stay",
  "Shopping",
  "Nightlife",
  "Wellness"
];

const visibilityOptions: Visibility[] = ["private", "friends", "public"];

type ActivityDraft = {
  title: string;
  city: string;
  date: string;
  time: string;
  category: Category;
  cost: string;
  durationHours: string;
  notes: string;
};

const emptyActivityDraft: ActivityDraft = {
  title: "",
  city: initialTrip.cityStops[0].city,
  date: initialTrip.cityStops[0].startDate,
  time: "10:00",
  category: "Food",
  cost: "25",
  durationHours: "2",
  notes: ""
};

function makeId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function dateList(startDate: string, endDate: string) {
  const dates: string[] = [];
  const [startYear, startMonth, startDay] = startDate.split("-").map(Number);
  const [endYear, endMonth, endDay] = endDate.split("-").map(Number);
  const cursor = new Date(Date.UTC(startYear, startMonth - 1, startDay));
  const end = new Date(Date.UTC(endYear, endMonth - 1, endDay));

  while (cursor <= end) {
    dates.push(cursor.toISOString().slice(0, 10));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }

  return dates;
}

function calendarDays(stops: CityStop[]) {
  return stops.flatMap((stop) =>
    dateList(stop.startDate, stop.endDate).map((date) => ({
      date,
      city: stop.city
    }))
  );
}

function formatDate(date: string, style: "short" | "weekday" = "short") {
  const parsed = new Date(`${date}T00:00:00`);

  return new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    weekday: style === "weekday" ? "short" : undefined
  }).format(parsed);
}

function formatMoney(amount: number, currency: Trip["currency"]) {
  return new Intl.NumberFormat("en", {
    style: "currency",
    currency,
    maximumFractionDigits: currency === "JPY" ? 0 : 0
  }).format(amount);
}

function categoryClass(category: Category) {
  return `tag ${category.toLowerCase()}`;
}

function sortedActivities(activities: Activity[]) {
  return [...activities].sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
}

function defaultDateForCity(stops: CityStop[], city: string) {
  return stops.find((stop) => stop.city === city)?.startDate ?? stops[0]?.startDate ?? new Date().toISOString().slice(0, 10);
}

export default function Home() {
  const [trip, setTrip] = useState<Trip>(initialTrip);
  const [activityDraft, setActivityDraft] = useState<ActivityDraft>(emptyActivityDraft);
  const [newStop, setNewStop] = useState({
    city: "",
    country: "",
    startDate: "2026-06-20",
    endDate: "2026-06-21",
    vibe: ""
  });
  const [discoveryQuery, setDiscoveryQuery] = useState("food");
  const [discoveryCity, setDiscoveryCity] = useState("");
  const [discoveryType, setDiscoveryType] = useState("");
  const [discoveryResults, setDiscoveryResults] = useState<DiscoveryItem[]>([]);
  const [activeView, setActiveView] = useState<"calendar" | "timeline">("calendar");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationNote, setGenerationNote] = useState("Ready for demo");
  const [collaboratorEmail, setCollaboratorEmail] = useState("");
  const [collaboratorRole, setCollaboratorRole] = useState<Collaborator["role"]>("editor");
  const [origin, setOrigin] = useState("https://traveloop.app");
  const [hasLoaded, setHasLoaded] = useState(false);
  const [saveState, setSaveState] = useState("Local cache active");

  useEffect(() => {
    const saved = window.localStorage.getItem("traveloop-trip");

    if (saved) {
      setTrip(JSON.parse(saved) as Trip);
    }

    setOrigin(window.location.origin);
    setHasLoaded(true);
  }, []);

  useEffect(() => {
    if (!hasLoaded) {
      return;
    }

    window.localStorage.setItem("traveloop-trip", JSON.stringify(trip));
    setSaveState("Saved locally");
    const timeout = window.setTimeout(() => setSaveState("Local cache active"), 1200);

    return () => window.clearTimeout(timeout);
  }, [trip, hasLoaded]);

  useEffect(() => {
    setActivityDraft((draft) => ({
      ...draft,
      city: trip.cityStops[0]?.city ?? draft.city,
      date: trip.cityStops[0]?.startDate ?? draft.date
    }));
  }, [trip.cityStops]);

  const days = useMemo(() => calendarDays(trip.cityStops), [trip.cityStops]);
  const orderedActivities = useMemo(() => sortedActivities(trip.activities), [trip.activities]);
  const totalCost = useMemo(() => trip.activities.reduce((sum, activity) => sum + activity.cost, 0), [trip.activities]);
  const remainingBudget = trip.budgetLimit - totalCost;
  const publicUrl = `${origin}/share/${trip.id}`;
  const friendUrl = `${origin}/share/${trip.id}?mode=edit`;

  const categoryTotals = useMemo(
    () =>
      categories
        .map((category) => ({
          category,
          total: trip.activities.filter((activity) => activity.category === category).reduce((sum, activity) => sum + activity.cost, 0)
        }))
        .filter((row) => row.total > 0),
    [trip.activities]
  );

  const cityTotals = useMemo(
    () =>
      trip.cityStops.map((stop) => ({
        city: stop.city,
        total: trip.activities.filter((activity) => activity.city === stop.city).reduce((sum, activity) => sum + activity.cost, 0)
      })),
    [trip.activities, trip.cityStops]
  );

  function updateTripField<K extends keyof Trip>(field: K, value: Trip[K]) {
    setTrip((current) => ({
      ...current,
      [field]: value
    }));
  }

  function updateStop(id: string, patch: Partial<CityStop>) {
    setTrip((current) => ({
      ...current,
      cityStops: current.cityStops.map((stop) => (stop.id === id ? { ...stop, ...patch } : stop))
    }));
  }

  function addStop(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!newStop.city.trim()) {
      return;
    }

    setTrip((current) => ({
      ...current,
      cityStops: [
        ...current.cityStops,
        {
          ...newStop,
          id: makeId("city"),
          city: newStop.city.trim(),
          country: newStop.country.trim() || "TBD",
          vibe: newStop.vibe.trim() || "Open day"
        }
      ]
    }));
    setNewStop({
      city: "",
      country: "",
      startDate: newStop.endDate,
      endDate: newStop.endDate,
      vibe: ""
    });
  }

  function removeStop(id: string) {
    const stop = trip.cityStops.find((item) => item.id === id);

    setTrip((current) => ({
      ...current,
      cityStops: current.cityStops.filter((item) => item.id !== id),
      activities: stop ? current.activities.filter((activity) => activity.city !== stop.city) : current.activities
    }));
  }

  function addActivity(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!activityDraft.title.trim()) {
      return;
    }

    const activity: Activity = {
      id: makeId("act"),
      title: activityDraft.title.trim(),
      city: activityDraft.city,
      date: activityDraft.date,
      time: activityDraft.time,
      category: activityDraft.category,
      cost: Number(activityDraft.cost) || 0,
      durationHours: Number(activityDraft.durationHours) || 1,
      notes: activityDraft.notes.trim(),
      votes: 0
    };

    setTrip((current) => ({
      ...current,
      activities: [...current.activities, activity]
    }));
    setActivityDraft({
      ...emptyActivityDraft,
      city: activity.city,
      date: activity.date
    });
  }

  function addDiscovery(item: DiscoveryItem) {
    const date = defaultDateForCity(trip.cityStops, item.city);

    setTrip((current) => ({
      ...current,
      activities: [
        ...current.activities,
        {
          id: makeId("disc"),
          title: item.title,
          city: item.city,
          date,
          time: item.time,
          category: item.category,
          cost: item.cost,
          durationHours: item.durationHours,
          notes: item.notes,
          votes: 0
        }
      ]
    }));
  }

  function removeActivity(id: string) {
    setTrip((current) => ({
      ...current,
      activities: current.activities.filter((activity) => activity.id !== id)
    }));
  }

  function updateActivity(id: string, patch: Partial<Activity>) {
    setTrip((current) => ({
      ...current,
      activities: current.activities.map((activity) => (activity.id === id ? { ...activity, ...patch } : activity))
    }));
  }

  function handleDrop(date: string, city: string, activityId: string) {
    updateActivity(activityId, { date, city });
  }

  async function searchDiscover(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();

    const params = new URLSearchParams();

    if (discoveryQuery) {
      params.set("query", discoveryQuery);
    }

    if (discoveryCity) {
      params.set("city", discoveryCity);
    }

    if (discoveryType) {
      params.set("type", discoveryType);
    }

    const response = await fetch(`/api/discover?${params.toString()}`);
    const payload = (await response.json()) as { results: DiscoveryItem[] };
    setDiscoveryResults(payload.results);
  }

  async function generateItinerary() {
    setIsGenerating(true);
    setGenerationNote("Generating...");

    const response = await fetch("/api/generate-itinerary", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        prompt: trip.prompt,
        cityStops: trip.cityStops,
        budgetLimit: trip.budgetLimit
      })
    });
    const payload = (await response.json()) as { summary: string; activities: Activity[] };

    setTrip((current) => ({
      ...current,
      activities: payload.activities
    }));
    setGenerationNote(payload.summary);
    setIsGenerating(false);
  }

  function addCollaborator(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!collaboratorEmail.trim()) {
      return;
    }

    setTrip((current) => ({
      ...current,
      collaborators: [
        ...current.collaborators,
        {
          id: makeId("collab"),
          email: collaboratorEmail.trim(),
          role: collaboratorRole
        }
      ]
    }));
    setCollaboratorEmail("");
  }

  function copyText(value: string) {
    navigator.clipboard?.writeText(value);
    setSaveState("Link copied");
    window.setTimeout(() => setSaveState("Local cache active"), 1200);
  }

  return (
    <main className="app">
      <header className="topbar">
        <div className="brand-block">
          <div className="brand-mark">TL</div>
          <div>
            <p className="eyebrow">Traveloop</p>
            <h1>{trip.title}</h1>
          </div>
        </div>
        <div className="top-actions">
          <span className="status-pill">{saveState}</span>
          <span className={`visibility ${trip.visibility}`}>{trip.visibility}</span>
          <button className="ghost-button" type="button" onClick={() => copyText(publicUrl)}>
            Copy share link
          </button>
        </div>
      </header>

      <section className="ai-console">
        <label htmlFor="prompt">AI trip brief</label>
        <textarea
          id="prompt"
          value={trip.prompt}
          onChange={(event) => updateTripField("prompt", event.target.value)}
          rows={3}
        />
        <div className="ai-footer">
          <p>{generationNote}</p>
          <button className="primary-button" type="button" onClick={generateItinerary} disabled={isGenerating || trip.cityStops.length === 0}>
            {isGenerating ? "Generating plan" : "Generate itinerary"}
          </button>
        </div>
      </section>

      <TravelOrbitScene stops={trip.cityStops} totalCost={totalCost} dayCount={days.length} activityCount={trip.activities.length} />

      <div className="workspace">
        <aside className="panel left-panel" aria-label="Planner controls">
          <section className="section-block">
            <div className="section-heading">
              <span>Trip Settings</span>
              <span>{days.length} days</span>
            </div>
            <label>
              Trip title
              <input value={trip.title} onChange={(event) => updateTripField("title", event.target.value)} />
            </label>
            <div className="split-fields">
              <label>
                Budget
                <input
                  type="number"
                  min="0"
                  value={trip.budgetLimit}
                  onChange={(event) => updateTripField("budgetLimit", Number(event.target.value))}
                />
              </label>
              <label>
                Currency
                <select value={trip.currency} onChange={(event) => updateTripField("currency", event.target.value as Trip["currency"])}>
                  <option>USD</option>
                  <option>INR</option>
                  <option>EUR</option>
                  <option>JPY</option>
                </select>
              </label>
            </div>
            <label>
              Visibility
              <select value={trip.visibility} onChange={(event) => updateTripField("visibility", event.target.value as Visibility)}>
                {visibilityOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
          </section>

          <section className="section-block">
            <div className="section-heading">
              <span>City Loop</span>
              <span>{trip.cityStops.length} stops</span>
            </div>
            <div className="stop-list">
              {trip.cityStops.map((stop, index) => (
                <article className="stop-row" key={stop.id}>
                  <div className="stop-index">{index + 1}</div>
                  <div className="stop-fields">
                    <div className="split-fields">
                      <input value={stop.city} onChange={(event) => updateStop(stop.id, { city: event.target.value })} aria-label="City" />
                      <input value={stop.country} onChange={(event) => updateStop(stop.id, { country: event.target.value })} aria-label="Country" />
                    </div>
                    <div className="split-fields">
                      <input type="date" value={stop.startDate} onChange={(event) => updateStop(stop.id, { startDate: event.target.value })} />
                      <input type="date" value={stop.endDate} onChange={(event) => updateStop(stop.id, { endDate: event.target.value })} />
                    </div>
                    <input value={stop.vibe} onChange={(event) => updateStop(stop.id, { vibe: event.target.value })} aria-label="Vibe" />
                  </div>
                  <button className="icon-button" type="button" onClick={() => removeStop(stop.id)} aria-label={`Remove ${stop.city}`}>
                    x
                  </button>
                </article>
              ))}
            </div>
            <form className="compact-form" onSubmit={addStop}>
              <div className="split-fields">
                <input placeholder="City" value={newStop.city} onChange={(event) => setNewStop({ ...newStop, city: event.target.value })} />
                <input placeholder="Country" value={newStop.country} onChange={(event) => setNewStop({ ...newStop, country: event.target.value })} />
              </div>
              <div className="split-fields">
                <input type="date" value={newStop.startDate} onChange={(event) => setNewStop({ ...newStop, startDate: event.target.value })} />
                <input type="date" value={newStop.endDate} onChange={(event) => setNewStop({ ...newStop, endDate: event.target.value })} />
              </div>
              <input placeholder="Trip vibe" value={newStop.vibe} onChange={(event) => setNewStop({ ...newStop, vibe: event.target.value })} />
              <button className="secondary-button" type="submit">
                Add city
              </button>
            </form>
          </section>

          <section className="section-block">
            <div className="section-heading">
              <span>Add Activity</span>
              <span>Manual</span>
            </div>
            <form className="compact-form" onSubmit={addActivity}>
              <input
                placeholder="Activity title"
                value={activityDraft.title}
                onChange={(event) => setActivityDraft({ ...activityDraft, title: event.target.value })}
              />
              <div className="split-fields">
                <select value={activityDraft.city} onChange={(event) => setActivityDraft({ ...activityDraft, city: event.target.value })}>
                  {trip.cityStops.map((stop) => (
                    <option key={stop.id}>{stop.city}</option>
                  ))}
                </select>
                <input type="date" value={activityDraft.date} onChange={(event) => setActivityDraft({ ...activityDraft, date: event.target.value })} />
              </div>
              <div className="triple-fields">
                <input type="time" value={activityDraft.time} onChange={(event) => setActivityDraft({ ...activityDraft, time: event.target.value })} />
                <select value={activityDraft.category} onChange={(event) => setActivityDraft({ ...activityDraft, category: event.target.value as Category })}>
                  {categories.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </select>
                <input
                  type="number"
                  min="0"
                  value={activityDraft.cost}
                  onChange={(event) => setActivityDraft({ ...activityDraft, cost: event.target.value })}
                  aria-label="Cost"
                />
              </div>
              <textarea
                placeholder="Notes"
                rows={3}
                value={activityDraft.notes}
                onChange={(event) => setActivityDraft({ ...activityDraft, notes: event.target.value })}
              />
              <button className="secondary-button" type="submit">
                Add activity
              </button>
            </form>
          </section>
        </aside>

        <section className="workbench" aria-label="Itinerary workspace">
          <div className="view-header">
            <div>
              <p className="eyebrow">Smart Itinerary</p>
              <h2>{orderedActivities.length} planned blocks</h2>
            </div>
            <div className="segmented">
              <button className={activeView === "calendar" ? "active" : ""} type="button" onClick={() => setActiveView("calendar")}>
                Calendar
              </button>
              <button className={activeView === "timeline" ? "active" : ""} type="button" onClick={() => setActiveView("timeline")}>
                Timeline
              </button>
            </div>
          </div>

          {activeView === "calendar" ? (
            <div className="calendar-grid">
              {days.map((day) => {
                const dayActivities = orderedActivities.filter((activity) => activity.date === day.date);

                return (
                  <article
                    className="day-card"
                    key={`${day.city}-${day.date}`}
                    onDragOver={(event) => event.preventDefault()}
                    onDrop={(event) => {
                      const id = event.dataTransfer.getData("text/plain");
                      handleDrop(day.date, day.city, id);
                    }}
                  >
                    <div className="day-card-header">
                      <div>
                        <span>{formatDate(day.date, "weekday")}</span>
                        <strong>{day.city}</strong>
                      </div>
                      <span>{dayActivities.length}</span>
                    </div>
                    <div className="activity-stack">
                      {dayActivities.map((activity) => (
                        <article
                          className="activity-card"
                          key={activity.id}
                          draggable
                          onDragStart={(event) => event.dataTransfer.setData("text/plain", activity.id)}
                        >
                          <div className="activity-topline">
                            <span>{activity.time}</span>
                            <span className={categoryClass(activity.category)}>{activity.category}</span>
                          </div>
                          <h3>{activity.title}</h3>
                          <p>{activity.notes}</p>
                          <div className="activity-meta">
                            <span>{formatMoney(activity.cost, trip.currency)}</span>
                            <span>{activity.durationHours}h</span>
                            <span>{activity.votes} votes</span>
                          </div>
                          <div className="activity-actions">
                            <button type="button" onClick={() => updateActivity(activity.id, { votes: activity.votes + 1 })}>
                              Vote
                            </button>
                            <button type="button" onClick={() => removeActivity(activity.id)}>
                              Remove
                            </button>
                          </div>
                        </article>
                      ))}
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="timeline-list">
              {orderedActivities.map((activity) => (
                <article className="timeline-item" key={activity.id}>
                  <div className="timeline-date">
                    <strong>{formatDate(activity.date)}</strong>
                    <span>{activity.time}</span>
                  </div>
                  <div className="timeline-content">
                    <div className="activity-topline">
                      <span>{activity.city}</span>
                      <span className={categoryClass(activity.category)}>{activity.category}</span>
                    </div>
                    <input value={activity.title} onChange={(event) => updateActivity(activity.id, { title: event.target.value })} />
                    <textarea rows={2} value={activity.notes} onChange={(event) => updateActivity(activity.id, { notes: event.target.value })} />
                    <div className="triple-fields">
                      <input type="date" value={activity.date} onChange={(event) => updateActivity(activity.id, { date: event.target.value })} />
                      <input type="time" value={activity.time} onChange={(event) => updateActivity(activity.id, { time: event.target.value })} />
                      <input
                        type="number"
                        min="0"
                        value={activity.cost}
                        onChange={(event) => updateActivity(activity.id, { cost: Number(event.target.value) || 0 })}
                      />
                    </div>
                  </div>
                  <button className="icon-button" type="button" onClick={() => removeActivity(activity.id)} aria-label={`Remove ${activity.title}`}>
                    x
                  </button>
                </article>
              ))}
            </div>
          )}
        </section>

        <aside className="panel right-panel" aria-label="Insights and sharing">
          <section className="section-block discover-block">
            <div className="section-heading">
              <span>Discover</span>
              <span>{discoveryResults.length} matches</span>
            </div>
            <form className="compact-form" onSubmit={searchDiscover}>
              <input placeholder="Search destination or activity" value={discoveryQuery} onChange={(event) => setDiscoveryQuery(event.target.value)} />
              <div className="split-fields">
                <select value={discoveryCity} onChange={(event) => setDiscoveryCity(event.target.value)}>
                  <option value="">All cities</option>
                  {trip.cityStops.map((stop) => (
                    <option key={stop.id}>{stop.city}</option>
                  ))}
                </select>
                <select value={discoveryType} onChange={(event) => setDiscoveryType(event.target.value)}>
                  <option value="">All types</option>
                  {categories.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </select>
              </div>
              <button className="secondary-button" type="submit">
                Search
              </button>
            </form>
            <div className="discovery-list">
              {discoveryResults.length === 0 ? (
                <button className="ghost-button full-width" type="button" onClick={() => searchDiscover()}>
                  Load recommendations
                </button>
              ) : (
                discoveryResults.map((item) => (
                  <article className="discovery-card" key={item.id}>
                    <div className="activity-topline">
                      <span>{item.city}</span>
                      <span className={categoryClass(item.category)}>{item.category}</span>
                    </div>
                    <h3>{item.title}</h3>
                    <p>{item.notes}</p>
                    <div className="activity-meta">
                      <span>{formatMoney(item.cost, trip.currency)}</span>
                      <span>{item.durationHours}h</span>
                    </div>
                    <button type="button" onClick={() => addDiscovery(item)}>
                      Add to trip
                    </button>
                  </article>
                ))
              )}
            </div>
          </section>

          <section className="section-block">
            <div className="section-heading">
              <span>Budget</span>
              <span className={remainingBudget >= 0 ? "positive" : "negative"}>{formatMoney(remainingBudget, trip.currency)}</span>
            </div>
            <div className="budget-hero">
              <div>
                <span>Total spend</span>
                <strong>{formatMoney(totalCost, trip.currency)}</strong>
              </div>
              <div className="budget-ring" style={{ "--progress": `${Math.min(100, (totalCost / Math.max(trip.budgetLimit, 1)) * 100)}%` } as React.CSSProperties}>
                <span>{Math.round((totalCost / Math.max(trip.budgetLimit, 1)) * 100)}%</span>
              </div>
            </div>
            <div className="breakdown-list">
              {categoryTotals.map((row) => (
                <div className="breakdown-row" key={row.category}>
                  <span>{row.category}</span>
                  <div className="bar-track">
                    <span style={{ width: `${Math.min(100, (row.total / Math.max(totalCost, 1)) * 100)}%` }} />
                  </div>
                  <strong>{formatMoney(row.total, trip.currency)}</strong>
                </div>
              ))}
            </div>
            <div className="city-total-grid">
              {cityTotals.map((row) => (
                <div key={row.city}>
                  <span>{row.city}</span>
                  <strong>{formatMoney(row.total, trip.currency)}</strong>
                </div>
              ))}
            </div>
          </section>

          <section className="section-block">
            <div className="section-heading">
              <span>Share</span>
              <span>{trip.collaborators.length} people</span>
            </div>
            <div className="share-list">
              <button type="button" onClick={() => copyText(publicUrl)}>
                Public plan
                <span>{publicUrl}</span>
              </button>
              <button type="button" onClick={() => copyText(friendUrl)}>
                Friend edit
                <span>{friendUrl}</span>
              </button>
            </div>
            <form className="compact-form" onSubmit={addCollaborator}>
              <div className="split-fields">
                <input
                  type="email"
                  placeholder="friend@email.com"
                  value={collaboratorEmail}
                  onChange={(event) => setCollaboratorEmail(event.target.value)}
                />
                <select value={collaboratorRole} onChange={(event) => setCollaboratorRole(event.target.value as Collaborator["role"])}>
                  <option value="editor">editor</option>
                  <option value="viewer">viewer</option>
                </select>
              </div>
              <button className="secondary-button" type="submit">
                Invite
              </button>
            </form>
            <div className="collab-list">
              {trip.collaborators.map((person) => (
                <div className="collab-row" key={person.id}>
                  <span>{person.email}</span>
                  <strong>{person.role}</strong>
                </div>
              ))}
            </div>
          </section>
        </aside>
      </div>
    </main>
  );
}
