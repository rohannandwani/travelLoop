import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import localtunnel from "localtunnel";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, "..");
const infoPath = path.join(root, "public-tunnel.json");

async function writeInfo(info) {
  await fs.writeFile(infoPath, `${JSON.stringify(info, null, 2)}\n`, "utf8");
}

try {
  const tunnel = await localtunnel({
    port: 3000,
    local_host: "127.0.0.1"
  });

  await writeInfo({
    url: tunnel.url,
    local: "http://127.0.0.1:3000",
    startedAt: new Date().toISOString(),
    status: "running"
  });

  tunnel.on("close", async () => {
    await writeInfo({
      url: tunnel.url,
      local: "http://127.0.0.1:3000",
      closedAt: new Date().toISOString(),
      status: "closed"
    });
  });

  process.on("SIGINT", () => tunnel.close());
  process.on("SIGTERM", () => tunnel.close());
} catch (error) {
  await writeInfo({
    status: "error",
    error: error instanceof Error ? error.message : String(error),
    failedAt: new Date().toISOString()
  });
  process.exit(1);
}
